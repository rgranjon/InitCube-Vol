/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Mode.h
 * Author: snir2g2
 *
 * Created on 8 avril 2019, 10:54
 */

#ifndef MODE_H
#define MODE_H

enum Mode {NORMAL, SLEEP, STAND_BY};

#endif /* MODE_H */

