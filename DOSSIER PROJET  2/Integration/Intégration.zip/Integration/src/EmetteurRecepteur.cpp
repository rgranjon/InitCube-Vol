/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   EmmetteurRecepteur.cpp
 * Author: snir2g1
 * 
 * Created on 21 mars 2019, 17:17
 */

#include "../defs/EmetteurRecepteur.h"

EmetteurRecepteur::EmetteurRecepteur() {
}

EmetteurRecepteur::EmetteurRecepteur(const EmetteurRecepteur& orig) {
}

EmetteurRecepteur::~EmetteurRecepteur() {
}

void EmetteurRecepteur::activerEmetteur(){
}

void EmetteurRecepteur::desativerEmetteur(){
}

